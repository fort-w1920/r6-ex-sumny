#' R6 Class representing a transaction log
#'
#' A transaction log stores a history of transactions for a bank account.
TransactionLog <- R6::R6Class(
  "TransactionLog",
  public = list(
    #' @description
    #' Print transaction history
    #' @return NULL
    print = function() {
      print(private$..log)
    }
  ),
  private = list(
    #' Dataframe with date, transaction and amount as colums
    ..log = data.frame(
      date = as.POSIXct(character()),
      transaction = character(),
      amount = numeric(),
      stringsAsFactors = FALSE
    )
  ),
  active = list(
    #' @field log Expose transaction log
    log = function(value) {
      if (missing(value)) {
        return(private$..log)
      }
      checkmate::assert_number(value)
      type <- ifelse(value < 0, "withdraw", "deposit")
      private$..log[nrow(private$..log) + 1,] <-
          list(Sys.time(), type, abs(value))
      invisible(self)
    })
)


