#' R6 Class SafeAccount
#'
#' @description A safe account has a balance and provides operations on this balance.
#' A safe account also has a history of transactions (see [TransactionLog]).
#'
#' @seealso [TransactionLog]
SafeAccount <- R6::R6Class(
  "SafeAccount",
  public = list(
    #' @description
    #' Create a new Account object.
    #' @param balance Initial account balance.
    #' @param account_holder Owner of the account
    #' @param log a [TransactionLog]
    #' @return A new `Account` object.
    initialize = function(balance = 0,
                          account_holder = person(),
                          log = NULL) {
      private$..balance <- balance
      private$..account_holder <- account_holder
      if (is.null(log)) {
        log <- TransactionLog$new()
        log$log <- balance
      }
      private$..log <- log
      self$validate()
    },
    #' @description
    #' Validate a freshly opened bank account.
    #' @return self
    validate = function() {
      checkmate::assert_number(private$..balance, finite = TRUE)
      checkmate::assert_class(private$..account_holder, "person")
      checkmate::assert_r6(private$..log, "TransactionLog")
      invisible(self)
    },
    #' @description
    #' print. duh.
    #' @return self
    print = function() {
      cat("Account: \n")
      cat("  Name:", print(private$..account_holder), "\n")
      cat("  Balance:  ", format(private$..balance, digits = 2), "\n")
      invisible(self)
    },
    #' @description
    #' Deposit money into account.
    #' @param amount Amount of money
    #' @return self
    deposit = function(amount) {
      checkmate::assert_number(amount, lower = 0, finite = TRUE)
      private$..update(amount)
    },
    #' @description
    #' Withdraw money from account.
    #' @param amount Amount of money
    #' @return self
    withdraw = function(amount) {
      checkmate::assert_number(amount, lower = 0, finite = TRUE)
      private$..update(-amount)
    },
    #'
    #'
    #' @description
    #' Alternative clone method for [SafeAccount]
    #'
    #' This makes sure that the log of the account is transferred to the new
    #' account correctly -- otherwise, we'd have to always remember to use
    #' `clone(deep = TRUE)`.
    #' @param deep see [R6::R6Class], section on cloning
    #' @return new Account
    clone2 = function(deep = TRUE) {
      # Note that overwriting the clone method itself is dangerous for more
      # complex classes -- the in-built `R6`-`clone` method does a lot more
      # behind the curtains than what we do here below. That's why I did
      # not call this `$clone()` -- remember that `R6` objects that themselves
      # contain objects with reference semantics (other `R6` objects or
      # environments) need extra care when you want to "copy" them!
        SafeAccount$new(balance = private$..balance,
                        account_holder = private$..account_holder,
                        log = if (deep) {
                          private$..log$clone()
                        } else {
                          private$..log
                        })
      }
    ),
  private = list(
    ..balance = 0,
    ..account_holder = person(),
    ..log = NULL,
    ..update = function(amount) {
      private$..balance <- private$..balance + amount
      private$..log$log <- amount
      invisible(self)
    }
  ),
  active = list(
    #' @field balance Expose account balance
    balance = function(value) {
      if (missing(value)) {
        return(private$..balance)
      }
      checkmate::assert_number(value, finite = TRUE)
      # active binding calls withdraw/deposit s.t. child classes can
      # implement their specific mechanisms here and logging takes place when
      # withdraw/deposit call ..update
      if (value < private$..balance) {
        self$withdraw(private$..balance - value)
      } else {
        self$deposit(value - private$..balance)
      }
    },
    #' @field account_holder Expose account holder(read only)
    account_holder = function() {
      return(private$..account_holder)
    },
    #' @field log Expose transaction log (read only)
    log = function() {
      return(private$..log)
    }
  )
)
