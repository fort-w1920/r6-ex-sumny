context("TransactionLog")

test_that("implementation for TransactionLog works", {
  log <- TransactionLog$new()
  checkmate::expect_r6(log, "TransactionLog")
  checkmate::expect_data_frame(log$log, ncol = 3)
  log$log <- 100
  log$log <- -100
  checkmate::expect_data_frame(log$log, nrows = 2)
  expect_equivalent(log$log$amount, c(100, 100))
  expect_equivalent(log$log$transaction, c("deposit", "withdraw"))
  expect_error(log$log <- "1 Fantastillarde", "number")
})
