context("Account & Giro Account")

test_that("implementation for Account works", {
  initial_balance <- 1000
  account <- Account$new(initial_balance)
  checkmate::expect_r6(account, "Account")

  account$deposit(100)
  expect_equivalent(account$balance, 1100)


  account$withdraw(200)
  expect_equivalent(account$balance, 900)

  account$withdraw(1000)
  expect_equivalent(account$balance, -100)

  expect_error(account$withdraw(-10), regexp = "not >= 0")
  expect_error(account$deposit(-10), regexp = "not >= 0")
})


test_that("implementation for GiroAccount works", {
  initial_balance <- 1000
  overdraft_max <- 500
  overdraft_percentage <- 5
  account <- GiroAccount$new(initial_balance, overdraft_max = overdraft_max,
                             overdraft_percentage = overdraft_percentage)
  expect_error(account$withdraw(initial_balance + overdraft_max),
               regexp = "Insufficient funds")
  expect_warning(account$withdraw(initial_balance + 1),
                 regexp = "Overcharge")
  expect_equivalent(account$balance, -(1 + overdraft_percentage/100))
  expect_equivalent(account$deposit(1 + overdraft_percentage/100)$balance,
                    0)
})


